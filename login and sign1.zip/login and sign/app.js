 const express = require("express");
 const jwt = require("jsonwebtoken");
 const bcrypt = require("bcryptjs");
 const cookieparser = require("cookie-parser");
 const app = express();
 app.set('view engine','ejs');
 var bodyParser = require('body-parser');
 var urlencodedParser = bodyParser.urlencoded({extended : true });
const auth = require('./middleware/auth');
 const mongoose =require("mongoose");
 const user = require('./models/signschema');
 const { response } = require("express");
 app.use(cookieparser());
  mongoose.connect('mongodb+srv://sagar_13:tanksagar134@cluster0.hy2up.mongodb.net/signdata?retryWrites=true&w=majority',
  { 
      useNewUrlParser:true,
      useUnifiedTopology:true
  });
  app.get("/home",function(req,res)
 {
     res.render('home'); 
 })
 app.get("/secret", auth,function(req,res)
 {
    console.log(req.cookies.jwtt);
     res.render('secret');
 })
 app.get("/logout",auth,(req,res)=>{
 try {
    res.clearCookie("jwt");
    console.log("logout");
     res.render('home');
 } catch (error) {
     res.send(error)
     
 }}
 
 )

 
 app.get("/sign",function(req,res)
 {
    res.render('sign');
     })

     app.post('/sign',urlencodedParser,function (req, res){
        
         const data=new user({
             _id:new mongoose.Types.ObjectId(),
             fname: req.body.fname,
             lname:req.body.lname,
             monum:req.body.monum,
             email:req.body.email,
             pwd:req.body.pwd  
            
         })
         const token = data.generateAuthToken();
      console.log(token);   
        res.cookie("jwt",token,{
            expires:new Date(Date.now() + 80000),
            httpOnly:true
        });
         data.save().then((result)=>{
             console.warn("save");     
         })
        .catch(err=>console.warn(err))
      
             res.render('login');

         })
 app.get("/login",function(req,res)
 {
    
     res.render('login');
 })      
 app.post("/login", urlencodedParser, async(req,res)=>{
     try
     {
         const emeil = req.body.email; 
         const passwrod = req.body.pwd; 
       
         const useremail = await user.findOne({email:emeil});
         const isMatch = bcrypt.compare(passwrod,useremail.pwd);
         const token = useremail.generateAuthToken();
         console.log(token);  

         res.cookie("jwt",token,{
            expires:new Date(Date.now() + 30000),
            httpOnly:true
        });

         if(isMatch){
             res.render("home");
         }else{
             res.send("passwrod not matchig");
         }
        
         }
         catch(error){
             res.send("invalid email")
         }
        
     })
  app.listen(3760);
 console.log("sagar");
