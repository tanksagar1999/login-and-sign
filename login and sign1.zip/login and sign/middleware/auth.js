const jwt = require("jsonwebtoken");


  


const auth =  (req,res,next) =>{
    try {
        const token = req.cookies.jwt;
        const verifyuser =  jwt.verify(token,"mynameissagartankandcomputerengkggmgkm");
        console.log(verifyuser);
        
        
        next();

    } catch (error) {
        res.send(err)
    }
}
module.exports = auth;
