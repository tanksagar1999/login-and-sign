var express = require('express');
var app = express();
app.set('view engine','ejs');
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded();
app.get('/login', function (req, res) {
    
   res.render('login')
})

app.post('/login',urlencodedParser, function (req, res) {
    response = {
        first_name:req.body.email,
        last_name:req.body.pwd
     };
     console.log(response);
     res.end(JSON.stringify(response));
   res.render('login')
})
app.listen(1244)
console.log("run")