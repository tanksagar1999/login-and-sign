const express = require("express");
const app = express();
const ejs = require('ejs')
const expressLayouts = require('express-ejs-layouts');
app.use(expressLayouts);
const path = require('path')
app.set('views',path.join(__dirname,'/src/views2'))
app.set('view engine','ejs');
const PORT = process.env.PORT || 3400



app.get("/home",function(req,res)
 {
     res.render('home');
 })
 app.listen(PORT , ()=>{
     console.log(`Listening on port ${PORT}`)
 })