const mongoose= require("mongoose");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { response } = require("express");
let signSchema= new mongoose.Schema(
    {
        _id:mongoose.Schema.Types.ObjectId,
        fname:String,
        lname:String,
        monum:String,
        email:String,
        pwd:String,
        tokens:[
        {token:{
            type:String,
            required:true
        }}
        ]
    }
);
signSchema.methods.generateAuthToken =  function(){
    try {
        
        const token = jwt.sign({_id:this._id.toString()},"mynameissagartankandcomputerengkggmgkm");
        this.tokens = this.tokens.concat({token:token})
         return(token);
        
    } catch (error) {
        res.send("errr");
        
    }
}
signSchema.pre("save",async function(next){
    if(this.isModified("pwd")){
        this.pwd = await bcrypt.hash(this.pwd,10);
        
    }
     next();
})

module.exports=mongoose.model('signschema',signSchema);